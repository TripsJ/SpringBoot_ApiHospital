package Works.trips.java.HospitalAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospitalApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
